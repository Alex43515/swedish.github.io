<?php

namespace EAddonsForElementor\Modules\Update;

use EAddonsForElementor\Base\Module_Base;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Update extends Module_Base {

    public function __construct() {
        parent::__construct();        
    }

}
